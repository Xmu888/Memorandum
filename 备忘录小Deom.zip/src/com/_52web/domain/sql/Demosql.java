package com._52web.domain.sql;

import com._52web.Uitls.JDBC.JDBCTemplatess;
import com._52web.web.data.DataMysql;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.objenesis.instantiator.basic.NewInstanceInstantiator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
/**
 * @author MrHao
 * @date 2019/4/29 14:41
 * @Effect  查询数据库中指定用户名有多少条备忘录   返回给 HTTP_Servlet中的doPost方法
 */
public class Demosql {
    public static List<DataMysql> getConeText(String username) throws Exception {
        JdbcTemplate JDBCTemp = JDBCTemplatess.getJt();//获取一个jdbcTemp对象
        String sql1 = "select id from inserUser where usernum=?";
        Map<String, Object> sop = JDBCTemp.queryForMap(sql1,username);
        Object id = sop.get("id");
        String sql = "SELECT id,text_name,text_time FROM usertextarea u WHERE u_id = "+id;
        List<DataMysql> data = JDBCTemp.query(sql, new BeanPropertyRowMapper<>(DataMysql.class));
//        DataMysql data = JDBCTemp.queryForObject();
        System.out.println(data);
//        ArrayList<DataMysql> data = (ArrayList<DataMysql>)JDBCTemp.query(sql, new BeanPropertyRowMapper<DataMysql>(DataMysql.class));
        return data;
    }
}
